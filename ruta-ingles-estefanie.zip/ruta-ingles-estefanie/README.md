# Ruta de inglés B2.1 → C1

Plan de estudio interactivo de 20 semanas (12 oct 2026 – 28 feb 2027), tres días por semana,
orientado a psicología, defensa de derechos humanos y comunicación profesional.

Página estática, sin dependencias ni backend. El avance, las notas y el glosario se guardan
en el `localStorage` del navegador de quien la usa: no viajan a ningún servidor, pero tampoco
se sincronizan entre dispositivos.

## Contenido

| Archivo | Qué es |
|---|---|
| `index.html` | La página completa: estilos, contenido y lógica en un solo archivo |
| `.nojekyll` | Evita que GitHub Pages procese el sitio con Jekyll |

## Publicar en GitHub Pages

1. Crea un repositorio nuevo, por ejemplo `ruta-ingles-estefanie`, y déjalo **público**
   (GitHub Pages gratuito solo publica repositorios públicos).
2. Sube `index.html` y `.nojekyll` a la raíz del repositorio. Desde la web:
   **Add file → Upload files → Commit changes**.
3. Entra a **Settings → Pages**.
4. En **Source** elige `Deploy from a branch`; en **Branch**, `main` y carpeta `/ (root)`. Guarda.
5. Espera uno o dos minutos. La página queda en:

   ```
   https://<tu-usuario>.github.io/ruta-ingles-estefanie/
   ```

Si prefieres hacerlo por consola:

```bash
git init
git add .
git commit -m "Ruta de inglés B2.1 a C1"
git branch -M main
git remote add origin https://github.com/<tu-usuario>/ruta-ingles-estefanie.git
git push -u origin main
```

Después activa Pages con los pasos 3 a 5.

## Modificar el plan

Todo el contenido vive en el bloque `<script>` al final de `index.html`:

- `L` — los enlaces externos, en un solo sitio.
- `PLAN` — los cinco meses, sus semanas y las tres tareas de cada semana.
  Cada tarea necesita un `id` único (es la llave con la que se guarda el avance),
  un `day`, un `text` y, opcionalmente, `url` + `go` para el enlace,
  y `tag` con `tagType: "cert"` o `"word"` para la etiqueta de color.
- `CERTS` y `TOOLS` — las tablas de certificados y de herramientas.

Las fechas `start` y `end` de cada semana son las que encienden el distintivo
«esta semana» cuando corresponde.

> Al cambiar un `id` de tarea se pierde el avance ya marcado de esa tarea.
> Si alguna vez rehaces el plan entero, sube también la versión en la constante `KEY`
> (`ruta-c1-estefanie-v2` → `v3`) para empezar con el tablero limpio.

## Colores

Paleta oro rosa, negro, blanco y rojo, definida como variables CSS en `:root`,
con su equivalente para modo oscuro. Cambiar un color es cambiar una línea.
